venv_path = ""

# this variable is assigned in start.py if venv is found
# this variable is added to sys.path and should prevent ModuleNotFoundErrors