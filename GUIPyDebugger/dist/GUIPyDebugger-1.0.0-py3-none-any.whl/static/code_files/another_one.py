def func1(x, y, z = 10):
    a = "world"
    print("hello")

def func2():
    b = "hello"
    print("world")