def func3():
	return "this is func 3"