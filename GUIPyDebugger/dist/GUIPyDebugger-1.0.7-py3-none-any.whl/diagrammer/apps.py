from django.apps import AppConfig


class DiagrammerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'diagrammer'
